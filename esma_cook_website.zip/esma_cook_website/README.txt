ESMA COOK — 5-page restaurant website

PAGES
- index.html (Home)
- about.html (Our Story)
- menu.html (Menu)
- gallery.html (Gallery)
- contact.html (Contact & Reservations)

PREVIEW
Open index.html in your browser. The site uses external Unsplash image URLs and Google Fonts, so an internet connection is needed to load the photography and fonts.

BEFORE PUBLISHING
1. Replace the sample dishes and TZS prices with the restaurant's real menu.
2. Replace the sample address, telephone, email and opening hours in the footer and contact page.
3. In script.js, replace reservations@esmacook.co.tz with the real reservation email.
4. The reservation form opens the visitor's email app; it does not automatically store bookings. For automatic bookings, connect a form service or backend.

HOSTING
- Netlify: drag the unzipped esma_cook_website folder into the Netlify manual deploy area.
- GitHub Pages: upload the files to a repository and enable Pages from the main branch/root.
- Any standard static web host: upload all files and folders, keeping the structure unchanged.

This is a starter website design, not a claim that ESMA COOK is an operating restaurant or that these sample menu items/prices are verified.
