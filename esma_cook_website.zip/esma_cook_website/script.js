const toggle=document.querySelector('.menu-toggle');
const nav=document.querySelector('nav');
if(toggle&&nav) toggle.addEventListener('click',()=>nav.classList.toggle('open'));
document.querySelectorAll('.menu-tabs button').forEach(btn=>btn.addEventListener('click',()=>{
 document.querySelectorAll('.menu-tabs button').forEach(b=>b.classList.remove('active'));
 btn.classList.add('active');
 const category=btn.dataset.category;
 document.querySelectorAll('.menu-item').forEach(item=>item.style.display=(category==='all'||item.dataset.category===category)?'flex':'none');
}));
const form=document.querySelector('#reservation-form');
if(form) form.addEventListener('submit',e=>{
 e.preventDefault();
 const data=new FormData(form);
 const subject=encodeURIComponent('Table reservation request — ESMA COOK');
 const body=encodeURIComponent(`Hello ESMA COOK,\n\nI would like to request a table reservation.\nName: ${data.get('name')}\nEmail: ${data.get('email')}\nPhone: ${data.get('phone')}\nDate: ${data.get('date')}\nTime: ${data.get('time')}\nGuests: ${data.get('guests')}\nNotes: ${data.get('notes')||'None'}\n\nPlease confirm availability. Thank you.`);
 window.location.href=`mailto:reservations@esmacook.co.tz?subject=${subject}&body=${body}`;
 document.querySelector('.notice').style.display='block';
});
document.querySelectorAll('[data-year]').forEach(el=>el.textContent=new Date().getFullYear());
